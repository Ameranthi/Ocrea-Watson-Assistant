# WA-Tester
A Tester for Watson Assistant Embeds 
